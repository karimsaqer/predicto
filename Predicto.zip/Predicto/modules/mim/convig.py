
class Config:
    def __init__(self, config_dict):
        self.__dict__.update(config_dict)